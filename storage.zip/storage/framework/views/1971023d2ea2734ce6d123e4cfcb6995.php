
<?php $__env->startSection('content'); ?>
    <div class="mb-4 mb-xl-5 pt-xl-1 pb-5"></div>
    <main>
      
        <div class="mb-4 pb-lg-3"></div>

        <section class="shop-main container d-flex">
            <div class="shop-sidebar side-sticky bg-body" id="shopFilter">
                <div class="aside-header d-flex d-lg-none align-items-center">
                    <h3 class="text-uppercase fs-6 mb-0">Filter By</h3>
                    <button class="btn-close-lg js-close-aside btn-close-aside ms-auto"></button>
                </div><!-- /.aside-header -->

                <div class="pt-4 pt-lg-0"></div>
                <div class="search-field__input-wrapper mb-3">
                    <input type="text" name="search_text"
                        class="search-field__input form-control form-control-sm border-light border-2" placeholder="SEARCH">
                </div>
                <div class="pt-4 pt-lg-0"></div>
                <div class="accordion" id="categories-list">
                    <div class="accordion-item mb-4 pb-3">
                        <h5 class="accordion-header" id="accordion-heading-11">
                            <button class="accordion-button p-0 border-0 fs-5 text-uppercase" type="button"
                                data-bs-toggle="collapse" data-bs-target="#accordion-filter-1" aria-expanded="true"
                                aria-controls="accordion-filter-1">
                                Danh mục sản phẩm
                                <svg class="accordion-button__icon type2" viewBox="0 0 10 6"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <g aria-hidden="true" stroke="none" fill-rule="evenodd">
                                        <path
                                            d="M5.35668 0.159286C5.16235 -0.053094 4.83769 -0.0530941 4.64287 0.159286L0.147611 5.05963C-0.0492049 5.27473 -0.049205 5.62357 0.147611 5.83813C0.344427 6.05323 0.664108 6.05323 0.860924 5.83813L5 1.32706L9.13858 5.83867C9.33589 6.05378 9.65507 6.05378 9.85239 5.83867C10.0492 5.62357 10.0492 5.27473 9.85239 5.06018L5.35668 0.159286Z" />
                                    </g>
                                </svg>
                            </button>
                        </h5>
                        <div id="accordion-filter-1" class="accordion-collapse collapse show border-0"
                            aria-labelledby="accordion-heading-11" data-bs-parent="#categories-list">
                            <div class="accordion-body px-0 pb-0 pt-3">
                                <ul class="list list-inline mb-0">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-item">
                                            <a href="<?php echo e(route('client.shop', ['category' => $category->name])); ?>"
                                                class="menu-link py-1">
                                                <?php echo e($category->name); ?> <span
                                                    class="text-muted">(<?php echo e($category->products_count); ?>)</span>
                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div><!-- /.accordion-item -->
                </div><!-- /.accordion-item -->

                <div class="accordion" id="categories-list">
                    <div class="accordion-item mb-4 pb-3">
                        <h5 class="accordion-header" id="accordion-heading-11">
                            <button class="accordion-button p-0 border-0 fs-5 text-uppercase" type="button"
                                data-bs-toggle="collapse" data-bs-target="#accordion-filter-1" aria-expanded="true"
                                aria-controls="accordion-filter-1">
                                Thương hiệu đồng hồ
                                <svg class="accordion-button__icon type2" viewBox="0 0 10 6"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <g aria-hidden="true" stroke="none" fill-rule="evenodd">
                                        <path
                                            d="M5.35668 0.159286C5.16235 -0.053094 4.83769 -0.0530941 4.64287 0.159286L0.147611 5.05963C-0.0492049 5.27473 -0.049205 5.62357 0.147611 5.83813C0.344427 6.05323 0.664108 6.05323 0.860924 5.83813L5 1.32706L9.13858 5.83867C9.33589 6.05378 9.65507 6.05378 9.85239 5.83867C10.0492 5.62357 10.0492 5.27473 9.85239 5.06018L5.35668 0.159286Z" />
                                    </g>
                                </svg>
                            </button>
                        </h5>
                        <div id="accordion-filter-1" class="accordion-collapse collapse show border-0"
                            aria-labelledby="accordion-heading-11" data-bs-parent="#categories-list">
                            <div class="accordion-body px-0 pb-0 pt-3">
                                <ul class="list list-inline mb-0">
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-item">
                                            <a href="<?php echo e(route('client.shop', ['brand' => $brand->name])); ?>"
                                                class="menu-link py-1">
                                                <?php echo e($brand->name); ?> <span
                                                    class="text-muted">(<?php echo e($brand->products_count); ?>)</span>
                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div><!-- /.accordion-item -->
                </div><!-- /.accordion-item -->



                <form action="<?php echo e(route('client.shop.filter')); ?>" method="GET">
                    <div class="accordion" id="price-filters">
                        <div class="accordion-item mb-4">
                            <h5 class="accordion-header mb-2" id="accordion-heading-price">
                                <button class="accordion-button p-0 border-0 fs-5 text-uppercase" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#accordion-filter-price" aria-expanded="true"
                                    aria-controls="accordion-filter-price">
                                    Lọc sản phẩm theo giá trị
                                    <svg class="accordion-button__icon type2" viewBox="0 0 10 6" xmlns="http://www.w3.org/2000/svg">
                                        <g aria-hidden="true" stroke="none" fill-rule="evenodd">
                                            <path
                                                d="M5.35668 0.159286C5.16235 -0.053094 4.83769 -0.0530941 4.64287 0.159286L0.147611 5.05963C-0.0492049 5.27473 -0.049205 5.62357 0.147611 5.83813C0.344427 6.05323 0.664108 6.05323 0.860924 5.83813L5 1.32706L9.13858 5.83867C9.33589 6.05378 9.65507 6.05378 9.85239 5.83867C10.0492 5.62357 10.0492 5.27473 9.85239 5.06018L5.35668 0.159286Z" />
                                        </g>
                                    </svg>
                                </button>
                            </h5>
                            <div id="accordion-filter-price" class="accordion-collapse collapse show border-0"
                                aria-labelledby="accordion-heading-price" data-bs-parent="#price-filters">
                                <input id="price-min" type="range" class="form-range" name="min_price" min="10000" max="1000000"
                                    step="5000" value="<?php echo e(request('min_price', 25000)); ?>">
                                <p class="text-secondary">Giá tối thiểu: <span class="fw-bold price-range__min">$<?php echo e(number_format(request('min_price', 25000))); ?></span></p>
                                <input id="price-max" type="range" class="form-range" name="max_price" min="10000" max="1000000"
                                    step="5000" value="<?php echo e(request('max_price', 450000)); ?>">
                                <p class="text-secondary">Giá tối đa: <span class="fw-bold price-range__max">$<?php echo e(number_format(request('max_price', 450000))); ?></span></p>
                
                                <!-- Button lọc -->
                                <button type="submit" class="w-100 btn btn-primary mt-3">Lọc theo giá</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div><!-- /.shop-sidebar -->

            <div class="shop-list flex-grow-1">
                <div class="d-flex justify-content-between mb-4 pb-md-2">
                    <div class="breadcrumb mb-0 d-none d-md-block flex-grow-1">
                        <a href="#" class="menu-link menu-link_us-s text-uppercase fw-medium">Home</a>
                        <span class="breadcrumb-separator menu-link fw-medium ps-1 pe-1">/</span>
                        <a href="#" class="menu-link menu-link_us-s text-uppercase fw-medium">The Shop</a>
                    </div><!-- /.breadcrumb -->

                    <div
                        class="shop-acs d-flex align-items-center justify-content-between justify-content-md-end flex-grow-1">
                        <select class="shop-acs__select form-select w-auto border-0 py-0 order-1 order-md-0"
                            aria-label="Sort Items" name="total-number">
                            <option selected>Default Sorting</option>
                            <option value="1">Featured</option>
                            <option value="2">Best selling</option>
                            <option value="3">Alphabetically, A-Z</option>
                            <option value="3">Alphabetically, Z-A</option>
                            <option value="3">Price, low to high</option>
                            <option value="3">Price, high to low</option>
                            <option value="3">Date, old to new</option>
                            <option value="3">Date, new to old</option>
                        </select>

                        <div class="shop-asc__seprator mx-3 bg-light d-none d-md-block order-md-0"></div>

                        <div class="col-size align-items-center order-1 d-none d-lg-flex">
                            <span class="text-uppercase fw-medium me-2">View</span>
                            <button class="btn-link fw-medium me-2 js-cols-size" data-target="products-grid"
                                data-cols="2">2</button>
                            <button class="btn-link fw-medium me-2 js-cols-size" data-target="products-grid"
                                data-cols="3">3</button>
                            <button class="btn-link fw-medium js-cols-size" data-target="products-grid"
                                data-cols="4">4</button>
                        </div><!-- /.col-size -->

                        <div class="shop-filter d-flex align-items-center order-0 order-md-3 d-lg-none">
                            <button class="btn-link btn-link_f d-flex align-items-center ps-0 js-open-aside"
                                data-aside="shopFilter">
                                <svg class="d-inline-block align-middle me-2" width="14" height="10"
                                    viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <use href="#icon_filter" />
                                </svg>
                                <span class="text-uppercase fw-medium d-inline-block align-middle">Filter</span>
                            </button>
                        </div><!-- /.col-size d-flex align-items-center ms-auto ms-md-3 -->
                    </div><!-- /.shop-acs -->
                </div><!-- /.d-flex justify-content-between -->

                <div class="products-grid row row-cols-2 row-cols-md-3" id="products-grid">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-card-wrapper">
                            <div class="product-card product-card_style6 hover-container mb-3">
                                <div class="pc__img-wrapper">
                                    <a href="<?php echo e(route('client.shop.show', $product->id)); ?>">
                                        <img style="border: 1px solid #e4e4e4" loading="lazy"
                                            src="<?php echo e(Storage::url($product->avatar ?? 'avatar/default.jpeg')); ?>"
                                            width="330" height="400" alt="<?php echo e($product->name); ?>" class="pc__img">
                                    </a>
                                </div>

                                <div style="border: 1px solid #e4e4e4" class="pc__info position-relative bg-body">
                                    <div class="position-relative">
                                        <p class="pc__category fs-13"><?php echo e($product->category->name ?? 'Danh mục'); ?></p>
                                        <h6 class="pc__title fs-base fw-semi-bold mb-1">
                                            <a
                                                href="<?php echo e(route('client.shop.show', $product->id)); ?>"><?php echo e($product->name); ?></a>
                                        </h6>
                                        <div class="product-card__price d-flex mb-1">
                                            <span
                                                class="money price fs-base fw-semi-bold">$<?php echo e($product->price_default); ?></span>
                                        </div>

                                        <div
                                            class="d-flex align-items-center hover__content position-relative mt-3 mt-sm-0">
                                            <!-- Nút Add to Cart -->
                                            <button class="btn-icon me-auto me-xxl-3 js-add-cart js-open-aside"
                                                data-aside="cartDrawer" title="Add To Cart">
                                                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                    <use href="#icon_cart"></use>
                                                </svg>
                                            </button>

                                            <!-- Nút Wishlist -->
                                            <button class="btn-icon js-add-wishlist" title="Add To Wishlist">
                                                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                    <use href="#icon_heart"></use>
                                                </svg>
                                            </button>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Hiển thị phân trang -->
                <div class="justify-content-center mt-4">
                    <?php echo e($products->links()); ?>

                </div>


            </div>
        </section><!-- /.shop-main container -->
    </main>
    <div class="mb-4 mb-xl-5 pt-xl-1 pb-5"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        let minPriceInput = document.getElementById("price-min");
        let maxPriceInput = document.getElementById("price-max");
        let minPriceDisplay = document.querySelector(".price-range__min");
        let maxPriceDisplay = document.querySelector(".price-range__max");

        // Hàm cập nhật giá khi kéo thanh trượt
        function updatePriceDisplay() {
            minPriceDisplay.textContent = formatCurrency(minPriceInput.value);
            maxPriceDisplay.textContent = formatCurrency(maxPriceInput.value);
        }

        // Hàm định dạng số thành tiền tệ
        function formatCurrency(value) {
            return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(value);
        }

        // Gán sự kiện khi thay đổi giá trị
        minPriceInput.addEventListener("input", updatePriceDisplay);
        maxPriceInput.addEventListener("input", updatePriceDisplay);

        // Cập nhật giá ban đầu khi tải trang
        updatePriceDisplay();
    });
</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .btn-icon {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background-color: #f1f1f1;
            border: none;
            transition: all 0.3s ease-in-out;
        }

        .btn-icon svg {
            width: 20px;
            height: 20px;
            fill: #333;
            transition: fill 0.3s ease-in-out;
        }

        /* Hiệu ứng hover */
        .btn-icon:hover {
            background-color: #1c1c1c;
            color: #fff;
        }

        .js-add-wishlist:hover {
            background-color: #a81717;
            color: #fff;
        }

        .btn-icon:hover svg {
            fill: #000;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eterna-watch\resources\views/client/shop.blade.php ENDPATH**/ ?>