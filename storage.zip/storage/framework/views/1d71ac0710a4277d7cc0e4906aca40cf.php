<?php $__env->startSection('content'); ?>
<section class="content pt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card" id="customerList">
                    <div class="card-header border-bottom-dashed">
        
                        <div class="row g-4 align-items-center">
                            <div class="col-sm">
                                <div>
                                    <h5 class="card-title mb-0">Thêm mới giá trị thuộc tính | <b><?php echo e($attribute->attribute_name); ?></b> </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <form action="<?php echo e(route('admin.attribute_values.store')); ?>" autocomplete="off" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="body row">
                               
                                <input type="hidden" name="attribute_id" value="<?php echo e($attribute->id); ?>">
                                <div class="mb-3 col-12">
                                    <label for="value_name" class="form-label">Gía trị thuộc tính</label>
                                    <input value="<?php echo e(old('value_name')); ?>" name="value_name" type="text" id="value_name"
                                        class="form-control" placeholder="Enter name">
                                    <?php $__errorArgs = ['value_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3 col-12">
                                    <label for="note" class="form-label">Ghi chú</label>
                                    <input value="<?php echo e(old('note')); ?>" name="note" type="text" id="note"
                                        class="form-control" placeholder="Enter name">
                                    <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
        
                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="hstack gap-2 justify-content-left">
                                <button type="submit" class="btn btn-success" id="add-btn">Thêm giá trị </button>
                                <a href="<?php echo e(route('admin.attribute_values.index', $attribute->id)); ?>" class="btn btn-light">Đóng</a>
                                <!-- <button type="button" class="btn btn-success" id="edit-btn">Update</button> -->
                            </div>
                        </div>
                    </form>
                </div>
        
        
            </div>

        </div>
    </div>
</section>


    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-lib'); ?>
    <script src="http://chiccorner-project.test/theme/velzon/assets/libs/list.js/list.min.js"></script>
    <script src="http://chiccorner-project.test/theme/velzon/assets/libs/list.pagination.js/list.pagination.min.js">
    </script>
    <script src="<?php echo e(asset('theme/velzon/assets/libs/list.js/list.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/velzon/assets/libs/list.pagination.js/list.pagination.min.js')); ?>"></script>

    <!--ecommerce-customer init js -->
    <script src="<?php echo e(asset('theme/velzon/assets/js/pages/ecommerce-customer-list.init.js')); ?>"></script>

    <!-- Sweet Alerts js -->
    <script src="<?php echo e(asset('theme/velzon/assets/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        document.getElementById('name').addEventListener('input', function() {
            // Lấy giá trị từ ô nhập liệu Tên danh mục
            var tenDanhMuc = this.value;

            // Chuyển đổi Tên danh mục thành Slug
            var slug = tenDanhMuc.toLowerCase()
                .normalize('NFD') // Chuẩn hóa Unicode để xử lý các ký tự tiếng Việt
                .replace(/[\u0300-\u036f]/g, '') // Xóa các dấu phụ
                .replace(/[^a-z0-9\s-]/g, '') // Xóa các ký tự đặc biệt không phải chữ cái Latin hoặc số
                .replace(/\s+/g, '-') // Thay thế khoảng trắng bằng dấu gạch ngang
                .replace(/-+/g, '-'); // Loại bỏ các dấu gạch ngang thừa

            // Gán giá trị Slug vào ô nhập liệu Slug
            document.getElementById('slug').value = slug;
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('theme/velzon/assets/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet"
        type="text/css" />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eterna-watch\resources\views/admin/attributes/create_detail.blade.php ENDPATH**/ ?>