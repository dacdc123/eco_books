<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link bg-info">
        <img src="<?php echo e(asset('theme/admin/dist/img/AdminLTELogo.png')); ?>" alt="AdminLTE Logo"
            class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light"><b>ETERNA WATCH</b></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <nav class="">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                    data-accordion="false">
                    <li style="background-color: rgb(86, 86, 86); border-radius: 4px" class="nav-item">
                        <a href="#" class="nav-link  d-flex align-items-center" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <img src=" <?php echo e(asset('theme\admin\dist\img\avatar.png')); ?>" class="nav-icon rounded-circle me-2"
                                alt="User Image" width="100%">

                            <p class="fw-semibold ml-2">Alexander Pierce</p>

                        </a>
                        <ul class="text-sm align-middle nav nav-treeview">
                            <li class="nav-item">
                                <a href="" class="nav-link">
                                    <i class="nav-icon fa-solid fa-caret-right nav-icon"></i>
                                    <p>Profile</p>
                                </a>
                            </li>
                            <form id="logout-form" action="" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                            <li class="nav-item">
                                <a onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                                    href="#" class="nav-link">
                                    <i class="nav-icon fa-solid fa-caret-right nav-icon"></i>
                                    <p>Đăng xuất</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>

        <!-- SidebarSearch Form -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.dashboard')); ?>"
                        class="nav-link <?php echo e(Request::routeIs('admin.dashboard') ? 'active' : ''); ?>">
                        <i class="nav-icon fa-solid fa-square-poll-vertical"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <li class="nav-item <?php echo e(Request::is('admin/categories*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa-solid fa-layer-group"></i>
                        <p>
                            Danh mục
                            <i class="nav-icon right fas fa-angle-left"></i>
                        </p>
                    </a>

                    <ul class="text-sm align-middle text-sm align-middle nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.categories.index')); ?>"
                                class="nav-link <?php echo e(Request::routeIs('admin.categories.index') ? 'active' : ''); ?>">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Danh sách</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.categories.create')); ?>"
                                class="nav-link <?php echo e(Request::routeIs('admin.categories.create') ? 'active' : ''); ?>">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Thêm mới</p>
                            </a>
                        </li>
                    </ul>
                </li>

                 <!-- quản lý banner -->
                 <li class="nav-item <?php echo e(Request::is('admin/banners*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa-solid fa-layer-group"></i>
                        <p>
                            Banner
                            <i class="nav-icon right fas fa-angle-left"></i>
                        </p>
                    </a>

                    <ul class="text-sm align-middle text-sm align-middle nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.banners.index')); ?>"
                                class="nav-link <?php echo e(Request::routeIs('admin.banners.index') ? 'active' : ''); ?>">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Danh sách</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.banners.create')); ?>"
                                class="nav-link <?php echo e(Request::routeIs('admin.banners.create') ? 'active' : ''); ?>">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Thêm mới</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item <?php echo e(Request::is('admin/users*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa-solid fa-user"></i>
                        <p>
                            Tài khoản
                            <i class="nav-icon right fas fa-angle-left"></i>
                        </p>
                    </a>

                    <ul class="text-sm align-middle nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.users.index', ['id' => 2])); ?>"
                                class="nav-link <?php echo e(Request::routeIs('admin.users.index') && request()->id == 2 ? 'active' : ''); ?>">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Nhân viên</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.users.index', ['id' => 3])); ?>"
                                class="nav-link <?php echo e(Request::routeIs('admin.users.index') && request()->id == 3 ? 'active' : ''); ?>">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Khách hàng</p>
                            </a>
                        </li>


                    </ul>

                </li>
                <li
                    class="nav-item <?php echo e(Request::is('admin/products*') || Request::is('admin/attributes*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa-solid fa-clock"></i>
                        <p>
                            Sản phẩm
                            <i class="nav-icon right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="text-sm align-middle text-sm align-middle nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.products.index')); ?>"
                                class="nav-link <?php echo e(Request::routeIs('admin.products.index') ? 'active' : ''); ?>">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Danh sách</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.products.create')); ?>"
                                class="nav-link <?php echo e(Request::routeIs('admin.attribute.create') ? 'active' : ''); ?>">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Thêm mới sản phẩm</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.attributes.index')); ?>"
                                class="nav-link <?php echo e(Request::routeIs('admin.attributes.index') ? 'active' : ''); ?>">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Thuộc tính sản phẩm</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-chart-pie"></i>
                        <p>
                            Thương hiệu
                            <i class="nav-icon right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.brands.index')); ?>" class="nav-link">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Danh sách</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.brands.create')); ?>" class="nav-link">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Thêm mới</p>
                            </a>
                        </li>
                    </ul>
                </li>

                
                <li class="nav-item <?php echo e(Request::is('admin/permissions*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa-solid fa-layer-group"></i>
                        <p>
                            Phân quyền
                            <i class="nav-icon right fas fa-angle-left"></i>
                        </p>
                    </a>

                    <ul class="text-sm align-middle text-sm align-middle nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.permissions.index')); ?>"
                                class="nav-link <?php echo e(Request::routeIs('admin.permissions.index') ? 'active' : ''); ?>">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Danh sách</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.permissions.create')); ?>"
                                class="nav-link <?php echo e(Request::routeIs('admin.permissions.create') ? 'active' : ''); ?>">
                                <i class="nav-icon fa-solid fa-caret-right"></i>
                                <p>Thêm mới</p>
                            </a>
                        </li>
                    </ul>
                </li>


                
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\laragon\www\eterna-watch\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>