<?php $__env->startSection('content'); ?>
    <div class="mb-4 mb-xl-5 pt-xl-1 pb-5"></div>
    <main style="padding-top: 90px;">
        <div class="mb-4 pb-4"></div>
        <section class="my-account container py-5">
            <div class="row">
                <div class="col-lg-3">
                    <nav class="nav flex-column border-end pe-3">
                        <a href="<?php echo e(route('account.dashboard')); ?>" class="nav-link text-dark fw-semibold">Bảng điều
                            khiển</a>
                        <a href="<?php echo e(route('account.order')); ?>" class="nav-link text-dark">Đơn hàng</a>
                        <a href="<?php echo e(route('account.address')); ?>" class="nav-link text-dark active">Địa chỉ</a>
                        <a href="<?php echo e(route('account.detail')); ?>" class="nav-link text-dark">Chi tiết tài khoản</a>
                        <a href="<?php echo e(route('account.wishlist')); ?>" class="nav-link text-dark">Danh sách yêu thích</a>

                        <form action="<?php echo e(route('client.logout')); ?>" method="POST" class="w-100">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="nav-link fw-semibold text-danger logout-btn">Đăng xuất</button>
                        </form>
                    </nav>
                </div>
                <div class="col-lg-9">
                    <div class="page-content my-account__address">
                        <p class="notice">The following addresses will be used on the checkout page by default.</p>
                        <div class="my-account__address-list">
                            <div class="my-account__address-item">
                                <div class="my-account__address-item__title">
                                    <h5>Billing Address</h5>
                                    <a href="#">Edit</a>
                                </div>
                                <div class="my-account__address-item__detail">
                                    <p>Daniel Robinson</p>
                                    <p>1418 River Drive, Suite 35 Cottonhall, CA 9622</p>
                                    <p>United States</p>
                                    <br>
                                    <p>sale@uomo.com</p>
                                    <p>+1 246-345-0695</p>
                                </div>
                            </div>
                            <div class="my-account__address-item">
                                <div class="my-account__address-item__title">
                                    <h5>Shipping Address</h5>
                                    <a href="#">Edit</a>
                                </div>
                                <div class="my-account__address-item__detail">
                                    <p>Daniel Robinson</p>
                                    <p>1418 River Drive, Suite 35 Cottonhall, CA 9622</p>
                                    <p>United States</p>
                                    <br>
                                    <p>sale@uomo.com</p>
                                    <p>+1 246-345-0695</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>


    <div class="mb-5 pb-xl-5"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .nav-link {
            font-size: 16px;
            padding: 12px 16px;
            transition: background-color 0.3s ease, padding-left 0.3s ease;
        }

        .nav-link:hover {
            background: #f0f0f0;
            padding-left: 20px;
        }

        .nav-link.active {
            background: hsl(0, 100%, 96%);
            font-weight: bold;
            color: #d3401f !important;
            border-left: 3px solid #fda3a3;
        }

        /* Hiệu ứng hover cho các liên kết */
        .link-hover {
            transition: color 0.3s ease-in-out;
        }

        .link-hover:hover {
            color: #0d47a1 !important;
            text-decoration: underline;
        }

        /* Bố cục nội dung đẹp hơn */
        .content-box {
            background: white;
            border-radius: 8px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .logout-btn {
            background: none;
            border: none;
            text-align: left;
            width: 100%;
            padding: 12px 16px;
            transition: background-color 0.3s, padding-left 0.3s;
            font-size: 16px;
            color: #c61a18 !important;
        }

        .logout-btn:hover {
            background: #f5f5f5;
            padding-left: 18px;
        }

        /* Responsive tối ưu */
        @media (max-width: 768px) {
            .container {
                max-width: 100%;
            }

            .nav {
                border-bottom: 1px solid #ddd;
            }

            .content-box {
                margin-top: 20px;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eterna-watch\resources\views/client/account/address.blade.php ENDPATH**/ ?>