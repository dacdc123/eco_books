<div class="aside aside_right overflow-hidden customer-forms" id="customerForms">
    <div class="customer-forms__wrapper d-flex position-relative">
        <div class="customer__login">
            <div class="aside-header d-flex align-items-center">
                <h3 class="text-uppercase fs-6 mb-0">Đăng nhập</h3>
                <button class="btn-close-lg js-close-aside ms-auto"></button>
            </div><!-- /.aside-header -->
            <form method="POST" action="<?php echo e(route('client.login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-floating mb-3">
                    <input name="email" type="email" class="form-control form-control_gray"
                        placeholder="name@example.com">
                    <label for="customerNameEmailInput">Nhập địa chỉ email *</label>
                </div>

                <div class="pb-3"></div>

                <div class="form-label-fixed mb-3">
                    <label for="customerPasswordInput" class="form-label">Password *</label>
                    <input name="password" class="form-control form-control_gray"
                        type="password" placeholder="********">
                </div>

                <div class="d-flex align-items-center mb-3 pb-2">
                    <div class="form-check mb-0">
                        <input name="remember" class="form-check-input form-check-input_fill" type="checkbox"
                            value="" id="flexCheckDefault">
                        <label class="form-check-label text-secondary" for="flexCheckDefault">Nhớ mật khẩu</label>
                    </div>
                    <a href="reset_password.html" class="btn-text ms-auto">Quên mật khẩu?</a>
                </div>

                <button class="btn btn-primary w-100 text-uppercase" type="submit">Đăng nhập</button>

                <div class="customer-option mt-4 text-center">
                    <span class="text-secondary">Bạn chưa có tài khoản?</span>
                    <a href="login_register.html#register-tab" class="btn-text js-show-register">Tạo mới tài khoản </a>
                </div>
            </form>
        </div><!-- /.customer__login -->

        <div class="customer__register">
            <div class="aside-header d-flex align-items-center">
                <h3 class="text-uppercase fs-6 mb-0">Create an account</h3>
                <button class="btn-close-lg js-close-aside btn-close-aside ms-auto"></button>
            </div><!-- /.aside-header -->

            <form action="https://uomo-html.flexkitux.com/Demo19/login_register.html" method="POST"
                class="aside-content">
                <div class="form-floating mb-4">
                    <input name="username" type="text" class="form-control form-control_gray"
                        id="registerUserNameInput" placeholder="Username">
                    <label for="registerUserNameInput">Username</label>
                </div>

                <div class="pb-1"></div>

                <div class="form-floating mb-4">
                    <input name="email" type="email" class="form-control form-control_gray"
                        id="registerUserEmailInput" placeholder="user@company.com">
                    <label for="registerUserEmailInput">Email address *</label>
                </div>

                <div class="pb-1"></div>

                <div class="form-label-fixed mb-4">
                    <label for="registerPasswordInput" class="form-label">Password *</label>
                    <input name="password" id="registerPasswordInput" class="form-control form-control_gray"
                        type="password" placeholder="*******">
                </div>

                <p class="text-secondary mb-4">Your personal data will be used to support your experience
                    throughout this website, to manage access to your account, and for other purposes described in
                    our privacy policy.</p>

                <button class="btn btn-primary w-100 text-uppercase" type="submit">Register</button>

                <div class="customer-option mt-4 text-center">
                    <span class="text-secondary">Already have account?</span>
                    <a href="#" class="btn-text js-show-login">Login</a>
                </div>
            </form>
        </div><!-- /.customer__register -->
    </div><!-- /.customer-forms__wrapper -->
</div><!-- /.aside aside_right -->
<?php /**PATH C:\laragon\www\eterna-watch\resources\views/client/layouts/auth.blade.php ENDPATH**/ ?>