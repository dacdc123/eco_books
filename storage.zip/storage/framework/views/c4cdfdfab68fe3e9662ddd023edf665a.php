

<?php $__env->startSection('content'); ?>
<section class="content pt-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card" id="customerList">
                    <div class="card-header border-bottom-dashed">
        
                        <div class="row g-4 align-items-center">
                            <div class="col-sm">
                                <div>
                                    <h5 class="card-title mb-0">Thêm mới tài khoản nhân viên</h5>
                                </div>
                            </div>
                        </div>
                    </div>
        
        
                    <form action="<?php echo e(route('admin.users.store')); ?>" autocomplete="off" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="body row">
                                <!-- Tên -->
                                <div class="mb-3 col-6">
                                    <label for="name" class="form-label">Họ và Tên</label>
                                    <input value="<?php echo e(old('name')); ?>" name="name" type="text" id="name"
                                        class="form-control" placeholder="Nhập họ và tên">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
        
                                <!-- Email -->
                                <div class="mb-3 col-6">
                                    <label for="email" class="form-label">Email</label>
                                    <input value="<?php echo e(old('email')); ?>" name="email" type="email" id="email"
                                        class="form-control" placeholder="Nhập email">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3 col-6">
                                    <label for="phone" class="form-label">Số điện thoại</label>
                                    <input value="<?php echo e(old('phone')); ?>" name="phone" type="text" id="phone"
                                        class="form-control" placeholder="Nhập số điện thoại">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
        
                                <!-- Mật khẩu -->
                                <div class="mb-3 col-6">
                                    <label for="password" class="form-label">Mật khẩu</label>
                                    <input name="password" type="password" id="password" class="form-control"
                                        placeholder="Nhập mật khẩu">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
        
                                <!-- Giới tính -->
                                <div class="mb-3 col-6">
                                    <label for="gender">Giới tính</label>
                                    <select name="gender" class="form-control">
                                        <option value="">Chọn giới tính</option>
                                        <option value="male">Nam</option>
                                        <option value="female">Nữ</option>
                                        <option value="other">Khác</option>
                                    </select>
                                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
        
                                <!-- Avatar -->
        
                                <!-- Ghi chú -->
                                
        
                                <!-- Vai trò -->
                                <div class="mb-3 col-6">
                                    <label for="role_id" class="form-label">Vai trò</label>
                                    <select name="role_id" class="form-control">
                                        <option value="">Chọn vai trò</option>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3 col-12">
                                    <label for="note" class="form-label">Ghi chú</label>
                                    <textarea name="note" id="note" class="form-control" rows="3" placeholder="Nhập ghi chú"><?php echo e(old('note')); ?></textarea>
                                    <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                               
                            </div>
                        </div>
        
                        <div class="card-footer">
                            <div class="hstack gap-2 justify-content-left">
                                <button type="submit" class="btn btn-success">Thêm tài khoản</button>
                                <a href="<?php echo e(route('admin.users.index',['id' => 2])); ?>" class="btn btn-light">Đóng</a>
                            </div>
                        </div>
                    </form>
        
                </div>
        
        
            </div>

        </div>
    </div>
</section>


    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-lib'); ?>
    <script src="http://chiccorner-project.test/theme/velzon/assets/libs/list.js/list.min.js"></script>
    <script src="http://chiccorner-project.test/theme/velzon/assets/libs/list.pagination.js/list.pagination.min.js">
    </script>
    <script src="<?php echo e(asset('theme/velzon/assets/libs/list.js/list.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/velzon/assets/libs/list.pagination.js/list.pagination.min.js')); ?>"></script>

    <!--ecommerce-customer init js -->
    <script src="<?php echo e(asset('theme/velzon/assets/js/pages/ecommerce-customer-list.init.js')); ?>"></script>

    <!-- Sweet Alerts js -->
    <script src="<?php echo e(asset('theme/velzon/assets/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('theme/velzon/assets/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet"
        type="text/css" />
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eterna-watch\resources\views/admin/users/create.blade.php ENDPATH**/ ?>