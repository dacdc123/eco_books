<?php $__env->startSection('content'); ?>
    <section class="content pt-3">
        <form action="<?php echo e(route('admin.productvariants.store')); ?>" autocomplete="off" method="POST"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input name="productId" value="<?php echo e($data->id); ?>" type="text" hidden>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card" id="customerList">
                            <div class=" card-header border-bottom-dashed ">

                                <div class="row g-4 align-items-center">
                                    <div class="col-sm">
                                        <div>
                                            <h5 class="card-title mb-0"><b>Thông tin sản phẩm</b></h5>
                                        </div>
                                    </div>
                                    <div class="col-sm-auto">
                                        <div class="d-flex flex-wrap align-items-start gap-2">
                                            <a href="<?php echo e(route('admin.products.edit', $data->id)); ?>"
                                                class="btn btn-warning add-btn"><i
                                                    class="ri-add-line align-bottom me-1"></i>Chỉnh sửa thông tin sản
                                                phẩm</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card-body">
                                <div class="row">
                                    <!-- Ảnh đại diện -->
                                    <div class="col-3">
                                        <div class="col-md-12 text-center">
                                            <img src="<?php echo e(asset('storage/' . $data->avatar)); ?>"
                                                class="img-fluid rounded shadow mb-3" style="object-fit: cover;"
                                                alt="Ảnh sản phẩm">
                                        </div>
                                        <div class="mb-3 col-md-12">
                                            <label for="name" class="form-label">Tên sản phẩm</label>
                                            <input type="text" name="name" id="name" class="form-control"
                                                value="<?php echo e($data->name); ?>" disabled>
                                        </div>

                                        <div class="mb-3 col-md-12">
                                            <label for="category" class="form-label">Danh mục</label>
                                            <select class="form-control" name="category_id" class="form-select" disabled>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>"
                                                        <?php echo e($category->id == $data->category->id ? 'selected' : ''); ?>>
                                                        <?php echo e($category->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="mb-3 col-md-12">
                                            <label for="brand" class="form-label">Thương hiệu</label>
                                            <select class="form-control" name="brand_id" class="form-select" disabled>
                                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($brand->id); ?>"
                                                        <?php echo e($brand->id == $data->brand->id ? 'selected' : ''); ?>>
                                                        <?php echo e($brand->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="mb-3 col-md-12">
                                            <label for="price_default" class="form-label">Giá mặc định</label>
                                            <input type="text" name="price_default" id="price_default"
                                                class="form-control"
                                                value="<?php echo e(number_format($data->price_default, 0, ',', '.')); ?>" disabled>
                                        </div>

                                        <div class="mb-3 col-md-12">
                                            <label for="status" class="form-label">Trạng thái</label>
                                            <select class="form-control" name="status" class="form-select" disabled>
                                                <option value="active" <?php echo e($data->status === 'active' ? 'selected' : ''); ?>>
                                                    Đang
                                                    bán
                                                </option>
                                                <option value="inactive"
                                                    <?php echo e($data->status === 'inactive' ? 'selected' : ''); ?>>
                                                    Ngừng bán
                                                </option>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="col-9">
                                        <div class="row">
                                            <div class="mb-4 col-12">
                                                <label for="status" class="form-label">Mô tả ngắn</label>
                                                <textarea name="short_description" id="short_description" class="form-control" rows="2"
                                                    placeholder="Nhập mô tả ngắn" disabled><?php echo e($data->short_description); ?></textarea>
                                                <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="mb-4 col-12 ">
                                                <label for="status" class="form-label">Mô tả đầy đủ</label>
                                                <textarea name="full_description" id="full_description" class="form-control summernote" rows="4"
                                                    placeholder="Nhập mô tả đầy đủ" disabled><?php echo e($data->full_description); ?></textarea>
                                                <?php $__errorArgs = ['full_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <form>
                            <div class="card" id="customerList">
                                <div class="card-header border-bottom-dashed">
                                    <div class="row g-4 align-items-center">
                                        <div class="col-sm">
                                            <div>
                                                <h5 class="card-title mb-0"><b>Các biến thể của sản phẩm</h5>
                                            </div>
                                        </div>
                                        <div class="col-sm-auto">
                                            <div class="d-flex flex-wrap align-items-start gap-2">
                                                <a href="<?php echo e(route('admin.productvariants.edit', $data->id)); ?>"
                                                    class="btn btn-warning add-btn"><i
                                                        class="ri-add-line align-bottom me-1"></i>Chỉnh sửa biến thể sản
                                                    phẩm</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="card-body">
                                    <div class="row">
                                        <table class="table table-bordered align-middle bg-light">
                                            <thead class="">
                                                <tr>
                                                    <th>Ảnh</th>
                                                    <th>Biến thể</th>
                                                    <th>SKU</th>
                                                    <th>Giá</th>
                                                    <th>Số lượng tồn</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $data->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td class="align-middle">
                                                            <?php if($variant->image): ?>
                                                                <img src="<?php echo e(asset('storage/' . $variant->image)); ?>"
                                                                    class="img-thumbnail" style="max-width: 50px;"
                                                                    alt="Ảnh biến thể">
                                                            <?php else: ?>
                                                                <span class="text-muted">Chưa có ảnh</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td class="align-middle">
                                                            <ul class="list-unstyled mb-0">
                                                                <?php $__currentLoopData = $variant->attributeValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li>
                                                                        <?php echo e($value->nameValue->attribute->attribute_name); ?>:
                                                                        <?php if($value->nameValue->attribute->attribute_name === 'Màu sắc'): ?>
                                                                            <div class="badge"
                                                                                style="background-color: <?php echo e($value->nameValue->note); ?>;">
                                                                                &nbsp;&nbsp;&nbsp;
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <?php echo e($value->nameValue->value_name); ?>

                                                                        <?php endif; ?>
                                                                    </li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </td>

                                                        <td class="align-middle"><?php echo e($variant->sku); ?></td>
                                                        <td class="align-middle">
                                                            <?php echo e(number_format($variant->price, 0, ',', '.')); ?> VND</td>
                                                        <td class="align-middle"><?php echo e($variant->stock); ?></td>

                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="5" class="text-center text-muted">Không có biến
                                                            thể
                                                            nào.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- Phần chứa form cho từng thuộc tính được tạo động -->
                                    <div id="attributes-value-forms"></div>

                                    <!-- Phần hiển thị tổ hợp biến thể (nếu cần) -->
                                    <div id="variants-combinations"></div>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
            </div>
        </form>
    </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>


    <!-- Khởi tạo Summernote cho textarea -->
    <script>
        $(document).ready(function() {
            $('.summernote').summernote({
                placeholder: 'Nhập mô tả đầy đủ',
                tabsize: 2,
                height: 620, // Chiều cao của editor
                toolbar: false, // Ẩn thanh công cụ
            });
    
            // Tắt chế độ chỉnh sửa (chỉ xem)
            $('.summernote').summernote('disable');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('theme/velzon/assets/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet"
        type="text/css" />
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eterna-watch\resources\views/admin/products/show.blade.php ENDPATH**/ ?>